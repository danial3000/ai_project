import numpy as np
import pygame
from environment import UnknownAngryBirds, PygameInit
from deep_q_learning import DQNAgent  # فایل جدا برای شبکه عصبی و عامل


if __name__ == "__main__":

    env = UnknownAngryBirds()
    screen, clock = PygameInit.initialization()
    FPS = 8

#----------------------------------
    # تنظیمات عامل
    state_dim = 64  # Grid flattened
    action_dim = 4  # Actions: Up, Down, Left, Right
    agent = DQNAgent(state_dim, action_dim)
#----------------------------------------------

    episode_reward = []
    for _ in range(5):

        state = env.reset() #اضافه شده
        state = env.get_grid_state()  # استفاده از تابع گرید برای استخراج وضعیت اولیه

        running = True
        total_reward = 0

        while running:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()

            env.render(screen)

            # انتخاب اکشن توسط عامل با استفاده از شبکه عصبی
            action = agent.select_action(state)  # انتخاب اکشن از شبکه عصبی
            next_state, reward, _, done = env.step(action)  # اجرای اکشن در محیط
            next_state = env.get_grid_state()  # وضعیت جدید گرید را بگیرید

            # ذخیره تجربه و آموزش عامل
            agent.store_transition(state, action, reward, next_state, done)
            agent.train()

            # به‌روزرسانی وضعیت فعلی
            state = next_state
            total_reward += reward

            if done:
                print(f"Episode finished with reward: {total_reward}")
                state = env.reset()
                state = env.get_grid_state()  # بازنشانی وضعیت محیط
                running = False

            pygame.display.flip()
            clock.tick(FPS)

    print(f'MEAN REWARD: {sum(episode_reward)/len(episode_reward)}')

    pygame.quit()
